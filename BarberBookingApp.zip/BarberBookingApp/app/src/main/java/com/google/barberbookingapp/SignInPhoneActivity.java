package com.google.barberbookingapp;

import android.content.SharedPreferences;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.google.barberbookingapp.databinding.ActivitySignInPhoneBinding;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class SignInPhoneActivity extends AppCompatActivity {

    private ActivitySignInPhoneBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_phone);

        binding= DataBindingUtil.setContentView(this , R.layout.activity_sign_in_phone);
        FirebaseApp.initializeApp(this);

        binding.signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendVerification();
            }
        });
    }

    private void sendVerification(){

        String phoneNumber = binding.editPhone.getText().toString();
        if (phoneNumber.isEmpty()){

            binding.editPhone.setError("Enter Phone Number");
            binding.editPhone.requestFocus();
            return;
        }
        if (phoneNumber.length()<10){
            binding.editPhone.setError("Enter Valid  Phone Number");
            binding.editPhone.requestFocus();
            return;
        }

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);
    }
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

        }

        @Override
        public void onVerificationFailed(FirebaseException e) {

        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);

            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);

            SharedPreferences.Editor myEdit = sharedPreferences.edit();

            myEdit.putString("CODE", s);

            myEdit.commit();
        }
    };
}
