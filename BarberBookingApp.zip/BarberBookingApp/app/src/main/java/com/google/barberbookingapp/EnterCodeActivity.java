package com.google.barberbookingapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class EnterCodeActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_code);

        FirebaseApp.initializeApp(this);
        mAuth=FirebaseAuth.getInstance();

        /*
        SharedPreferences sh
    = getSharedPreferences("MySharedPref",
                           MODE_APPEND);

String s1 = sh.getString("CODE", "");
         */

    }
}
